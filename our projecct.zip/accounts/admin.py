from django.contrib import admin
from .models import UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'travel_type', 'budget_pref', 'location', 'created_at']
    search_fields = ['user__username', 'user__email']
    list_filter = ['travel_type', 'budget_pref']
