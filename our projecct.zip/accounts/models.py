from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver


class UserProfile(models.Model):
    TRAVEL_CHOICES = [
        ('adventure', 'Adventure'),
        ('leisure', 'Leisure'),
        ('heritage', 'Heritage & Culture'),
        ('nature', 'Nature'),
        ('beach', 'Beach'),
        ('mountain', 'Mountain'),
        ('religious', 'Religious'),
    ]
    BUDGET_CHOICES = [
        ('budget', 'Budget'),
        ('mid', 'Mid-Range'),
        ('luxury', 'Luxury'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    bio = models.TextField(blank=True)
    phone = models.CharField(max_length=15, blank=True)
    location = models.CharField(max_length=100, blank=True)
    travel_type = models.CharField(max_length=20, choices=TRAVEL_CHOICES, blank=True)
    budget_pref = models.CharField(max_length=10, choices=BUDGET_CHOICES, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} Profile'


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)
