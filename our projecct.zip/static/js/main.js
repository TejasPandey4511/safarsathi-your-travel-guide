// Travel Buddy — Main JavaScript

document.addEventListener('DOMContentLoaded', function () {

  // Auto-dismiss alerts after 4 seconds
  document.querySelectorAll('.alert.alert-dismissible').forEach(function (alert) {
    setTimeout(function () {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      bsAlert.close();
    }, 4000);
  });

  // Activate current nav link
  const currentPath = window.location.pathname;
  document.querySelectorAll('.navbar .nav-link').forEach(function (link) {
    if (link.getAttribute('href') === currentPath) {
      link.classList.add('active');
    }
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Rating star interaction (for forms using radio buttons)
  const ratingInputs = document.querySelectorAll('input[name="rating"]');
  ratingInputs.forEach(function (input) {
    input.addEventListener('change', function () {
      const val = parseInt(this.value);
      ratingInputs.forEach(function (r, i) {
        const label = r.nextElementSibling;
        if (label) {
          const star = label.querySelector('i');
          if (star) {
            star.className = i < val ? 'bi bi-star-fill text-warning' : 'bi bi-star text-warning';
          }
        }
      });
    });
  });

  // Destination image lazy loading fallback
  document.querySelectorAll('img[src=""]').forEach(function (img) {
    img.src = '/static/images/default.jpg';
  });
  document.querySelectorAll('img').forEach(function (img) {
    img.addEventListener('error', function () {
      if (!this.dataset.errorHandled) {
        this.dataset.errorHandled = 'true';
        this.src = '/static/images/default.jpg';
      }
    });
  });

  // Tooltip initialization
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
    new bootstrap.Tooltip(el);
  });

  // Search input focus on / key
  document.addEventListener('keydown', function (e) {
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      const searchInput = document.querySelector('input[name="q"]');
      if (searchInput) searchInput.focus();
    }
  });

});
