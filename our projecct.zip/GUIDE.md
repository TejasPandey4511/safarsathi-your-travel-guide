# Travel Buddy — Setup & Working Guide

---

## 1. Activate Environment & Install

```bash
D:\webcoss\env\Scripts\activate
pip install -r requirements.txt
```

---

## 2. Configure API Keys

Copy `.env.example` → `.env` and add your keys:

```
GEMINI_API_KEY=your-gemini-key       # https://aistudio.google.com/app/apikey
GROK_API_KEY=your-grok-key           # https://console.x.ai/
DEFAULT_AI_PROVIDER=gemini
```

---

## 3. Setup Database

```bash
python manage.py makemigrations accounts core chatbot
python manage.py migrate
python manage.py seed_data
```

---

## 4. Run Server

```bash
python manage.py runserver
```

Open → **http://127.0.0.1:8000**

---

## Default Logins

| Role  | Username | Password |
|-------|----------|----------|
| Admin | admin    | admin123 |
| User  | demo     | demo123  |

Admin Panel → http://127.0.0.1:8000/admin

---

## All Pages

| URL                  | Page                   |
|----------------------|------------------------|
| `/`                  | Home                   |
| `/destinations/`     | Search & browse places |
| `/destination/<slug>/` | Place detail + book  |
| `/chatbot/`          | AI Chat                |
| `/recommendations/`  | AI picks for you       |
| `/bookings/`         | Your bookings          |
| `/reports/`          | Your analytics         |
| `/reports/admin/`    | Admin analytics        |
| `/accounts/profile/` | Edit profile           |
| `/admin/`            | Django admin panel     |

---

---

# WEBSITE WORKING FLOW

---

## Flow 1 — New User Registration

```
User visits /accounts/register/
        |
        v
Fills form (username, name, email, password)
        |
        v
Django creates:
  - auth_user table     → stores username, email, password (hashed)
  - accounts_userprofile → auto-created via signal (travel_type, budget_pref = empty)
        |
        v
User is logged in automatically → redirected to /  (home)
```

**DB Tables written:**
- `auth_user` — 1 new row
- `accounts_userprofile` — 1 new row (linked to user)

---

## Flow 2 — Login

```
User visits /accounts/login/
        |
        v
Enters username + password
        |
        v
Django checks auth_user table (password hash match)
        |
  YES --+-- NO → show error
  |
  v
Session created → django_session table
        |
        v
Redirected to /dashboard/
```

**DB Tables written:**
- `django_session` — 1 new row (session key + user data)

---

## Flow 3 — Home Page

```
User visits /
        |
        v
Django queries:
  - core_destination  WHERE is_featured=True  → Featured cards
  - core_category     ORDER BY dest count     → Category icons
  - core_destination  ORDER BY -rating        → Top Rated section
  - core_review       ORDER BY -created_at    → Recent Reviews
        |
        v
Page rendered with real DB data
```

**DB Tables read:** `core_destination`, `core_category`, `core_review`

---

## Flow 4 — Search & Filter Destinations

```
User visits /destinations/?q=goa&category=beach&budget=mid
        |
        v
Django filters core_destination table:
  WHERE name ILIKE '%goa%'
    AND category__slug = 'beach'
    AND budget = 'mid'
        |
        v
If user is logged in → saves search to core_searchlog table
        |
        v
Results shown with count, cards, filter UI
```

**DB Tables read:** `core_destination`, `core_category`
**DB Tables written:** `core_searchlog` — 1 row (keyword, results_count, user, timestamp)

---

## Flow 5 — Destination Detail Page

```
User visits /destination/taj-mahal/
        |
        v
Django fetches:
  - core_destination WHERE slug='taj-mahal'   → main details
  - core_review      WHERE destination=this   → all reviews
  - AVG(rating) calculated                    → avg rating
  - core_destination WHERE category=same      → similar places
        |
        v
visit_count + 1 saved to core_destination
        |
        v
Page shows: images, map (Leaflet.js), reviews, booking form, AI chat button
```

**DB Tables read:** `core_destination`, `core_review`
**DB Tables written:** `core_destination` — visit_count field updated

---

## Flow 6 — Booking a Destination

```
User fills booking form on detail page (travel_date, num_people, notes)
        |
        v
POST → /destination/taj-mahal/book/
        |
        v
Django creates core_booking row:
  - user         = logged-in user
  - destination  = taj-mahal
  - travel_date  = selected date
  - num_people   = count
  - status       = 'pending'   ← default
        |
        v
Redirected to /bookings/ (My Bookings page)
```

**DB Tables written:** `core_booking` — 1 new row

**Booking Status Flow:**
```
pending  →  confirmed  (admin changes in /admin/)
pending  →  cancelled  (user clicks Cancel button)
```

---

## Flow 7 — Writing a Review

```
User submits review form on destination detail page
        |
        v
POST → /destination/taj-mahal/review/
        |
        v
Django creates core_review row:
  - user        = logged-in user
  - destination = taj-mahal
  - rating      = 1-5
  - comment     = text
        |
        v
Django recalculates destination:
  - rating      = AVG of all reviews for this place
  - review_count = COUNT of reviews
  - Saves updated values to core_destination
        |
        v
Redirected back to destination page
```

**DB Tables written:** `core_review` — 1 new row
**DB Tables updated:** `core_destination` — rating, review_count fields

**Note:** One user = one review per destination (unique_together constraint)

---

## Flow 8 — AI Chatbot

```
User visits /chatbot/
        |
        v
If no session → Django creates chatbot_chatsession row (UUID, user, provider)
        |
        v
User types message → JavaScript sends POST to /chatbot/send/
        |
        v
Django saves user message to chatbot_chatmessage (role='user')
        |
        v
Builds conversation history from last 10 messages
        |
        v
Calls AI service (chatbot/ai_service.py):
  |
  +-- if provider = 'gemini':
  |     LangChain → ChatGoogleGenerativeAI → Gemini API → response
  |
  +-- if provider = 'grok':
        OpenAI client (xAI base URL) → Grok API → response
        |
        v
AI reply saved to chatbot_chatmessage (role='assistant')
        |
        v
JSON response sent back → JS renders bubble in chat UI
        |
        v
Session title auto-set from first user message
```

**DB Tables written:**
- `chatbot_chatsession` — 1 row per conversation
- `chatbot_chatmessage` — 2 rows per exchange (user + assistant)

---

## Flow 9 — AI Recommendations

```
User visits /recommendations/
        |
        v
recommendation_engine.py runs:
  1. Gets user profile (travel_type, budget_pref)
  2. Finds destinations already booked or reviewed → exclude them
  3. Filters core_destination by matching category & budget
  4. Falls back to top-rated if not enough results
        |
        v
Old recommendations deleted → new ones saved to core_recommendation
        |
        v
Page shows personalized destination cards
```

**DB Tables read:** `accounts_userprofile`, `core_booking`, `core_review`, `core_destination`
**DB Tables written:** `core_recommendation` — fresh rows every visit

**Better recommendations = fill profile preferences** (travel type + budget)

---

## Flow 10 — Reports Page

```
User visits /reports/
        |
        v
Django queries for this user:
  - COUNT core_booking              → total bookings
  - COUNT core_review               → total reviews
  - COUNT chatbot_chatsession       → AI chat count
  - core_searchlog last 10          → recent searches
  - core_review GROUP BY rating     → rating distribution data
  - core_booking GROUP BY month     → last 6 months trend
  - core_destination ORDER BY visits → top visited
        |
        v
All data passed to template
        |
        v
Chart.js renders:
  - Bar chart   → monthly bookings
  - Doughnut    → ratings given
```

**DB Tables read:** `core_booking`, `core_review`, `chatbot_chatsession`, `core_searchlog`, `core_destination`

---

## Flow 11 — Admin Reports (Staff Only)

```
Staff user visits /reports/admin/
        |
        v
Django checks user.is_staff → if False → redirect to home
        |
        v
Queries entire system:
  - COUNT auth_user           → total users
  - COUNT core_destination    → total places
  - COUNT core_booking        → all bookings
  - COUNT core_review         → all reviews
  - core_destination top 10 by visit_count
  - core_category with dest_count + booking_count
  - core_booking  last 10 (all users)
  - core_review   last 10 (all users)
        |
        v
Chart.js renders system-wide charts
```

---

---

# DATABASE TABLES

---

## auth_user  (Django built-in)
| Field      | Type    | Notes                  |
|------------|---------|------------------------|
| id         | INT PK  |                        |
| username   | VARCHAR | unique                 |
| email      | VARCHAR |                        |
| password   | VARCHAR | hashed (bcrypt)        |
| first_name | VARCHAR |                        |
| last_name  | VARCHAR |                        |
| is_staff   | BOOL    | True = admin access    |
| date_joined| DATETIME|                        |

---

## accounts_userprofile
| Field       | Type    | Notes                              |
|-------------|---------|------------------------------------|
| id          | INT PK  |                                    |
| user_id     | FK      | → auth_user                        |
| avatar      | IMAGE   | uploaded to media/avatars/         |
| bio         | TEXT    |                                    |
| phone       | VARCHAR |                                    |
| location    | VARCHAR |                                    |
| travel_type | VARCHAR | adventure/leisure/heritage/nature… |
| budget_pref | VARCHAR | budget / mid / luxury              |
| created_at  | DATETIME|                                    |

---

## core_category
| Field | Type    | Notes              |
|-------|---------|--------------------|
| id    | INT PK  |                    |
| name  | VARCHAR | Heritage, Beach…   |
| slug  | VARCHAR | heritage-culture…  |
| icon  | VARCHAR | Bootstrap icon cls |
| color | VARCHAR | #hex color         |

**Seeded with 8 rows:** Heritage, Nature, Beach, Mountain, Religious, Adventure, Leisure, Hill Station

---

## core_destination
| Field        | Type     | Notes                        |
|--------------|----------|------------------------------|
| id           | INT PK   |                              |
| name         | VARCHAR  | Taj Mahal, Goa Beaches…      |
| slug         | VARCHAR  | taj-mahal, goa-beaches…      |
| category_id  | FK       | → core_category              |
| description  | TEXT     | full description             |
| short_desc   | VARCHAR  | 300 chars for cards          |
| state        | VARCHAR  | Uttar Pradesh, Kerala…       |
| city         | VARCHAR  | Agra, Alleppey…              |
| latitude     | DECIMAL  | for Leaflet map              |
| longitude    | DECIMAL  | for Leaflet map              |
| image        | IMAGE    | uploaded file                |
| image_url    | URL      | external URL (seeded data)   |
| budget       | VARCHAR  | free/budget/mid/luxury       |
| best_season  | VARCHAR  | Oct-Mar, Nov-Feb…            |
| entry_fee    | VARCHAR  | Rs.50, Free…                 |
| rating       | DECIMAL  | 0.0-5.0, auto-updated        |
| review_count | INT      | auto-updated on review save  |
| visit_count  | INT      | +1 every detail page view    |
| is_featured  | BOOL     | shown on home page           |
| is_active    | BOOL     | hide without deleting        |

**Seeded with 8 rows:** Taj Mahal, Kerala Backwaters, Goa Beaches, Manali, Varanasi, Ranthambore, Darjeeling, Rishikesh

---

## core_review
| Field          | Type     | Notes                      |
|----------------|----------|----------------------------|
| id             | INT PK   |                            |
| destination_id | FK       | → core_destination         |
| user_id        | FK       | → auth_user                |
| rating         | INT      | 1 to 5                     |
| comment        | TEXT     |                            |
| created_at     | DATETIME |                            |

**Constraint:** 1 review per user per destination

---

## core_booking
| Field          | Type     | Notes                        |
|----------------|----------|------------------------------|
| id             | INT PK   |                              |
| user_id        | FK       | → auth_user                  |
| destination_id | FK       | → core_destination           |
| travel_date    | DATE     | selected by user             |
| num_people     | INT      | 1-20                         |
| notes          | TEXT     | optional special requests    |
| status         | VARCHAR  | pending/confirmed/cancelled  |
| created_at     | DATETIME |                              |

---

## core_searchlog
| Field         | Type     | Notes                    |
|---------------|----------|--------------------------|
| id            | INT PK   |                          |
| user_id       | FK       | → auth_user (nullable)   |
| keyword       | VARCHAR  | search term entered      |
| results_count | INT      | how many results found   |
| created_at    | DATETIME |                          |

---

## core_recommendation
| Field          | Type     | Notes                          |
|----------------|----------|--------------------------------|
| id             | INT PK   |                                |
| user_id        | FK       | → auth_user                    |
| destination_id | FK       | → core_destination             |
| reason         | TEXT     | why recommended (optional)     |
| score          | FLOAT    | = destination.rating           |
| created_at     | DATETIME |                                |

**Note:** Cleared and re-generated every time user visits /recommendations/

---

## chatbot_chatsession
| Field      | Type     | Notes                    |
|------------|----------|--------------------------|
| id         | INT PK   |                          |
| session_id | UUID     | unique, used in URL      |
| user_id    | FK       | → auth_user              |
| title      | VARCHAR  | auto-set from 1st message|
| provider   | VARCHAR  | gemini or grok           |
| created_at | DATETIME |                          |
| updated_at | DATETIME |                          |

---

## chatbot_chatmessage
| Field      | Type     | Notes               |
|------------|----------|---------------------|
| id         | INT PK   |                     |
| session_id | FK       | → chatsession       |
| role       | VARCHAR  | user or assistant   |
| content    | TEXT     | message text        |
| created_at | DATETIME |                     |

---

## django_session  (built-in)
Stores login session. Auto-managed by Django.

---

## Table Relationships

```
auth_user
  |-- accounts_userprofile  (1-to-1)
  |-- core_booking          (1-to-many)
  |-- core_review           (1-to-many)
  |-- core_searchlog        (1-to-many)
  |-- core_recommendation   (1-to-many)
  |-- chatbot_chatsession   (1-to-many)

core_category
  |-- core_destination      (1-to-many)

core_destination
  |-- core_review           (1-to-many)
  |-- core_booking          (1-to-many)
  |-- core_recommendation   (1-to-many)

chatbot_chatsession
  |-- chatbot_chatmessage   (1-to-many)
```

---

## Common Commands

```bash
python manage.py seed_data        # re-seed sample data
python manage.py createsuperuser  # create new admin
python manage.py collectstatic    # for production
python manage.py shell            # Django shell (DB queries)
```

**Check DB via shell:**
```python
python manage.py shell
>>> from core.models import Destination
>>> Destination.objects.all()
>>> Destination.objects.filter(is_featured=True)
```
