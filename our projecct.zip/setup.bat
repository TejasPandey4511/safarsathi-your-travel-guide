@echo off
echo ==========================================
echo   Travel Buddy - Setup Script
echo ==========================================
echo.

REM Use existing D:\webcoss\env if present, otherwise create venv
if exist "D:\webcoss\env\Scripts\python.exe" (
    set PYTHON=D:\webcoss\env\Scripts\python.exe
    set PIP=D:\webcoss\env\Scripts\pip.exe
    echo Using existing env at D:\webcoss\env
) else (
    echo [1/5] Creating virtual environment...
    python -m venv venv
    set PYTHON=venv\Scripts\python.exe
    set PIP=venv\Scripts\pip.exe
)

echo [2/5] Installing dependencies...
%PIP% install -r requirements.txt

echo [3/5] Copying .env file...
if not exist .env (
    copy .env.example .env
    echo   Created .env - add your API keys!
) else (
    echo   .env already exists
)

echo [4/5] Running migrations...
%PYTHON% manage.py makemigrations accounts core chatbot
%PYTHON% manage.py migrate

echo [5/5] Seeding sample data...
%PYTHON% manage.py seed_data

echo.
echo ==========================================
echo   Setup Complete!
echo ==========================================
echo.
echo   To start the server:
echo     venv\Scripts\activate
echo     python manage.py runserver
echo.
echo   Open: http://127.0.0.1:8000
echo   Admin: http://127.0.0.1:8000/admin
echo   Login: admin / admin123
echo ==========================================
pause
