from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
import json

from .models import ChatSession, ChatMessage
from .ai_service import get_ai_response


@login_required
def chat_view(request):
    sessions = ChatSession.objects.filter(user=request.user)[:10]
    # Get or create active session
    session_id = request.GET.get('session')
    if session_id:
        session = get_object_or_404(ChatSession, session_id=session_id, user=request.user)
    else:
        session = ChatSession.objects.filter(user=request.user).first()
        if not session:
            session = ChatSession.objects.create(user=request.user)

    messages = session.messages.all()
    quick_prompts = [
        'Best beaches in Goa',
        'Hill stations near Mumbai',
        'Budget trip to Rajasthan',
        'Hidden gems in Kerala',
    ]
    return render(request, 'chatbot/chat.html', {
        'session': session,
        'sessions': sessions,
        'messages': messages,
        'quick_prompts': quick_prompts,
    })


@login_required
def new_session(request):
    session = ChatSession.objects.create(user=request.user)
    return JsonResponse({'session_id': str(session.session_id)})


@login_required
@require_POST
def send_message(request):
    try:
        data = json.loads(request.body)
        user_message = data.get('message', '').strip()
        session_id = data.get('session_id')
        provider = data.get('provider', 'gemini')

        if not user_message:
            return JsonResponse({'error': 'Empty message'}, status=400)

        session = get_object_or_404(ChatSession, session_id=session_id, user=request.user)

        # Save user message
        ChatMessage.objects.create(session=session, role='user', content=user_message)

        # Build history for context (exclude the message just saved)
        history = [
            {'role': msg.role, 'content': msg.content}
            for msg in list(session.messages.all())[:-1]
        ]

        # Update session provider
        if session.provider != provider:
            session.provider = provider
            session.save()

        # Get AI response
        ai_reply = get_ai_response(user_message, history, provider)

        # Save AI response
        ChatMessage.objects.create(session=session, role='assistant', content=ai_reply)

        # Update session title from first message
        if session.messages.count() == 2:
            session.title = user_message[:50]
            session.save()

        return JsonResponse({'reply': ai_reply, 'session_id': str(session.session_id)})

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@login_required
def delete_session(request, session_id):
    session = get_object_or_404(ChatSession, session_id=session_id, user=request.user)
    session.delete()
    return JsonResponse({'status': 'deleted'})
