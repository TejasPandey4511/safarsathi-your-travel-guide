"""
AI Service — supports Groq and Google Gemini via LangChain.
"""
from django.conf import settings

SYSTEM_PROMPT = """You are Travel Buddy, a friendly and knowledgeable AI travel guide for India.
You help users discover amazing destinations, plan trips, get travel tips, and answer any
tourism-related questions. Be helpful, concise, and enthusiastic about travel.
Always suggest destinations in India when relevant and provide practical travel advice."""


def get_ai_response(user_message: str, history: list, provider: str = None) -> str:
    """
    Get AI response using LangChain with Groq or Gemini.
    history: list of {'role': 'user'/'assistant', 'content': '...'}
    """
    provider = provider or settings.DEFAULT_AI_PROVIDER

    try:
        if provider == 'gemini':
            return _gemini_response(user_message, history)
        else:
            return _groq_response(user_message, history)
    except Exception as e:
        return f"I'm sorry, I encountered an error: {str(e)}. Please check your API key configuration."


def _groq_response(user_message: str, history: list) -> str:
    from langchain_groq import ChatGroq
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

    api_key = settings.GROQ_API_KEY
    if not api_key:
        return "Groq API key is not configured. Please add GROQ_API_KEY to your .env file."

    llm = ChatGroq(
        model="llama3-8b-8192",
        groq_api_key=api_key,
        temperature=0.7,
    )

    messages = [SystemMessage(content=SYSTEM_PROMPT)]
    for msg in history[-10:]:
        if msg['role'] == 'user':
            messages.append(HumanMessage(content=msg['content']))
        else:
            messages.append(AIMessage(content=msg['content']))
    messages.append(HumanMessage(content=user_message))

    response = llm.invoke(messages)
    return response.content


def _gemini_response(user_message: str, history: list) -> str:
    from langchain_google_genai import ChatGoogleGenerativeAI
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

    api_key = settings.GEMINI_API_KEY
    if not api_key:
        return "Gemini API key is not configured. Please add GEMINI_API_KEY to your .env file."

    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",
        google_api_key=api_key,
        temperature=0.7,
    )

    messages = [SystemMessage(content=SYSTEM_PROMPT)]
    for msg in history[-10:]:
        if msg['role'] == 'user':
            messages.append(HumanMessage(content=msg['content']))
        else:
            messages.append(AIMessage(content=msg['content']))
    messages.append(HumanMessage(content=user_message))

    response = llm.invoke(messages)
    return response.content
