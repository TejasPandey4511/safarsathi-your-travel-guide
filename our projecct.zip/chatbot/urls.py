from django.urls import path
from . import views

app_name = 'chatbot'

urlpatterns = [
    path('', views.chat_view, name='chat'),
    path('new/', views.new_session, name='new_session'),
    path('send/', views.send_message, name='send'),
    path('delete/<uuid:session_id>/', views.delete_session, name='delete_session'),
]
