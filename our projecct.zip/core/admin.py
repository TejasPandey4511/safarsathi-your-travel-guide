from django.contrib import admin
from .models import Category, Destination, Review, Booking, SearchLog, Recommendation


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'icon', 'color']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Destination)
class DestinationAdmin(admin.ModelAdmin):
    list_display = ['name', 'city', 'state', 'category', 'rating', 'budget', 'is_featured', 'is_active']
    list_filter = ['category', 'budget', 'is_featured', 'is_active', 'state']
    search_fields = ['name', 'city', 'state']
    prepopulated_fields = {'slug': ('name',)}
    list_editable = ['is_featured', 'is_active']


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['user', 'destination', 'rating', 'created_at']
    list_filter = ['rating']
    search_fields = ['user__username', 'destination__name']


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ['user', 'destination', 'travel_date', 'num_people', 'status', 'created_at']
    list_filter = ['status']
    list_editable = ['status']


@admin.register(SearchLog)
class SearchLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'keyword', 'results_count', 'created_at']
    readonly_fields = ['created_at']


@admin.register(Recommendation)
class RecommendationAdmin(admin.ModelAdmin):
    list_display = ['user', 'destination', 'score', 'created_at']
