from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('destinations/', views.destination_list, name='destinations'),
    path('destination/<slug:slug>/', views.destination_detail, name='destination_detail'),
    path('destination/<slug:slug>/review/', views.add_review, name='add_review'),
    path('destination/<slug:slug>/book/', views.book_destination, name='book_destination'),
    path('bookings/', views.my_bookings, name='my_bookings'),
    path('bookings/<int:pk>/cancel/', views.cancel_booking, name='cancel_booking'),
    path('recommendations/', views.recommendations_view, name='recommendations'),
    path('reports/', views.reports_view, name='reports'),
    path('reports/admin/', views.admin_reports, name='admin_reports'),
]
