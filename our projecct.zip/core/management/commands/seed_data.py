"""
Management command to seed sample data for Travel Buddy.
Usage: python manage.py seed_data
"""
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from core.models import Category, Destination


CATEGORIES = [
    {'name': 'Heritage & Culture', 'icon': 'bi-building', 'color': '#e74c3c'},
    {'name': 'Nature & Wildlife', 'icon': 'bi-tree', 'color': '#27ae60'},
    {'name': 'Beach & Coastal', 'icon': 'bi-water', 'color': '#3498db'},
    {'name': 'Mountain & Trekking', 'icon': 'bi-geo-alt', 'color': '#8e44ad'},
    {'name': 'Religious & Spiritual', 'icon': 'bi-stars', 'color': '#f39c12'},
    {'name': 'Adventure', 'icon': 'bi-lightning', 'color': '#e67e22'},
    {'name': 'Leisure & Relaxation', 'icon': 'bi-umbrella', 'color': '#1abc9c'},
    {'name': 'Hill Station', 'icon': 'bi-cloud', 'color': '#2980b9'},
]

DESTINATIONS = [
    {
        'name': 'Taj Mahal',
        'city': 'Agra', 'state': 'Uttar Pradesh',
        'category': 'Heritage & Culture',
        'description': 'The Taj Mahal is an ivory-white marble mausoleum on the south bank of the Yamuna river. Built by Mughal emperor Shah Jahan in memory of his wife, it is one of the Seven Wonders of the World.',
        'short_desc': 'Iconic marble mausoleum, one of the Seven Wonders of the World.',
        'budget': 'mid', 'best_season': 'Oct-Mar', 'entry_fee': '₹1100 (foreigners) / ₹50 (Indians)',
        'rating': 4.8, 'review_count': 1200, 'visit_count': 5000,
        'is_featured': True,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Taj_Mahal_%28Edited%29.jpeg/1200px-Taj_Mahal_%28Edited%29.jpeg',
        'latitude': 27.1751, 'longitude': 78.0421,
    },
    {
        'name': 'Kerala Backwaters',
        'city': 'Alleppey', 'state': 'Kerala',
        'category': 'Leisure & Relaxation',
        'description': 'The backwaters of Kerala are a network of interconnected canals, rivers, lakes, and inlets formed by more than 900 km of waterways. A houseboat cruise here is a quintessential Kerala experience.',
        'short_desc': 'Serene network of canals and lakes, famous for houseboat cruises.',
        'budget': 'mid', 'best_season': 'Nov-Feb', 'entry_fee': 'Varies by houseboat',
        'rating': 4.7, 'review_count': 890, 'visit_count': 3800,
        'is_featured': True,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/Kerala_backwater.jpg/1200px-Kerala_backwater.jpg',
        'latitude': 9.4981, 'longitude': 76.3388,
    },
    {
        'name': 'Goa Beaches',
        'city': 'Panaji', 'state': 'Goa',
        'category': 'Beach & Coastal',
        'description': "Goa's beaches stretch along the Arabian Sea coastline and are known for their golden sand, swaying palms, and vibrant nightlife. Popular beaches include Baga, Calangute, Anjuna, and Palolem.",
        'short_desc': 'Vibrant beaches with golden sand, nightlife, and Portuguese heritage.',
        'budget': 'mid', 'best_season': 'Nov-Feb', 'entry_fee': 'Free',
        'rating': 4.6, 'review_count': 2100, 'visit_count': 8000,
        'is_featured': True,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Baga_Beach_Goa.jpg/1200px-Baga_Beach_Goa.jpg',
        'latitude': 15.5004, 'longitude': 73.8093,
    },
    {
        'name': 'Manali',
        'city': 'Manali', 'state': 'Himachal Pradesh',
        'category': 'Mountain & Trekking',
        'description': 'Manali is a high-altitude Himalayan resort town in the Kullu valley in Himachal Pradesh. It is a starting point for many Himalayan treks and Leh-Ladakh road trips.',
        'short_desc': 'Himalayan hill station, gateway to Rohtang Pass and Ladakh.',
        'budget': 'mid', 'best_season': 'Mar-Jun, Sep-Nov', 'entry_fee': 'Free',
        'rating': 4.5, 'review_count': 1560, 'visit_count': 6200,
        'is_featured': True,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Manali_valley.jpg/1200px-Manali_valley.jpg',
        'latitude': 32.2432, 'longitude': 77.1892,
    },
    {
        'name': 'Varanasi Ghats',
        'city': 'Varanasi', 'state': 'Uttar Pradesh',
        'category': 'Religious & Spiritual',
        'description': 'Varanasi is one of the world oldest living cities and is considered the spiritual capital of India. The Ganga Aarti ceremony at Dashashwamedh Ghat is a breathtaking spiritual experience.',
        'short_desc': "Ancient city on the Ganges, India's spiritual capital.",
        'budget': 'budget', 'best_season': 'Oct-Mar', 'entry_fee': 'Free',
        'rating': 4.7, 'review_count': 980, 'visit_count': 4100,
        'is_featured': True,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Varanasi_Ghats.jpg/1200px-Varanasi_Ghats.jpg',
        'latitude': 25.3176, 'longitude': 82.9739,
    },
    {
        'name': 'Ranthambore National Park',
        'city': 'Sawai Madhopur', 'state': 'Rajasthan',
        'category': 'Nature & Wildlife',
        'description': 'Ranthambore National Park is one of the best places in India to see Bengal tigers. The park also houses ancient ruins, including the Ranthambore Fort, within its boundaries.',
        'short_desc': 'Famous tiger reserve with ancient ruins in Rajasthan.',
        'budget': 'premium', 'best_season': 'Oct-Jun', 'entry_fee': '₹500-₹2500',
        'rating': 4.5, 'review_count': 680, 'visit_count': 2900,
        'is_featured': False,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Tigress_at_Ranthambhore.jpg/1200px-Tigress_at_Ranthambhore.jpg',
        'latitude': 26.0173, 'longitude': 76.5026,
    },
    {
        'name': 'Darjeeling',
        'city': 'Darjeeling', 'state': 'West Bengal',
        'category': 'Hill Station',
        'description': 'Darjeeling is a town in West Bengal known for its tea industry, the Darjeeling Himalayan Railway (a UNESCO World Heritage Site), and stunning views of Kangchenjunga.',
        'short_desc': 'Famous for tea gardens, Toy Train, and Himalayan views.',
        'budget': 'mid', 'best_season': 'Mar-May, Sep-Nov', 'entry_fee': 'Free',
        'rating': 4.6, 'review_count': 820, 'visit_count': 3500,
        'is_featured': False,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/DarjeelingTrain.JPG/1200px-DarjeelingTrain.JPG',
        'latitude': 27.0410, 'longitude': 88.2663,
    },
    {
        'name': 'Rishikesh',
        'city': 'Rishikesh', 'state': 'Uttarakhand',
        'category': 'Adventure',
        'description': 'Rishikesh is a holy city in the foothills of the Himalayas known as the "Yoga Capital of the World". It offers white water rafting, bungee jumping, and trekking opportunities.',
        'short_desc': 'Yoga capital of the world with thrilling adventure sports.',
        'budget': 'budget', 'best_season': 'Sep-Nov, Feb-May', 'entry_fee': 'Free',
        'rating': 4.6, 'review_count': 1100, 'visit_count': 4700,
        'is_featured': True,
        'image_url': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/43/LaxmanJhula.jpg/1200px-LaxmanJhula.jpg',
        'latitude': 30.0869, 'longitude': 78.2676,
    },
]


class Command(BaseCommand):
    help = 'Seed the database with sample categories, destinations, and a demo admin user'

    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding data...')

        # Create categories
        cat_map = {}
        for c in CATEGORIES:
            obj, created = Category.objects.get_or_create(name=c['name'], defaults={'icon': c['icon'], 'color': c['color']})
            cat_map[c['name']] = obj
            if created:
                self.stdout.write(f'  Created category: {c["name"]}')

        # Create destinations
        for d in DESTINATIONS:
            cat = cat_map.get(d.pop('category'))
            obj, created = Destination.objects.get_or_create(
                name=d['name'],
                defaults={**d, 'category': cat}
            )
            if created:
                self.stdout.write(f'  Created destination: {obj.name}')

        # Create demo admin
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@travelbuddy.com', 'admin123')
            self.stdout.write('  Created admin user: admin / admin123')

        # Create demo user
        if not User.objects.filter(username='demo').exists():
            user = User.objects.create_user('demo', 'demo@travelbuddy.com', 'demo123', first_name='Demo', last_name='User')
            self.stdout.write('  Created demo user: demo / demo123')

        self.stdout.write(self.style.SUCCESS('Database seeded successfully!'))
        self.stdout.write('  Admin: admin / admin123')
        self.stdout.write('  Demo:  demo / demo123')
