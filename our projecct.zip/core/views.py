from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Avg, Count
from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta

from .models import Destination, Category, Review, Booking, SearchLog, Recommendation
from .forms import ReviewForm, BookingForm
from .recommendation_engine import get_recommendations


# ─── Home ────────────────────────────────────────────────────────────────────

def home(request):
    featured = Destination.objects.filter(is_featured=True, is_active=True)[:6]
    categories = Category.objects.annotate(count=Count('destinations')).order_by('-count')[:8]
    top_rated = Destination.objects.filter(is_active=True).order_by('-rating')[:4]
    recent_reviews = Review.objects.select_related('user', 'destination').order_by('-created_at')[:5]
    return render(request, 'core/home.html', {
        'featured': featured,
        'categories': categories,
        'top_rated': top_rated,
        'recent_reviews': recent_reviews,
    })


# ─── Dashboard ───────────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    user_bookings = Booking.objects.filter(user=request.user).order_by('-created_at')[:5]
    user_reviews = Review.objects.filter(user=request.user).order_by('-created_at')[:5]
    recommendations = get_recommendations(request.user, limit=6)
    chat_count = request.user.chat_sessions.count()
    return render(request, 'core/dashboard.html', {
        'bookings': user_bookings,
        'reviews': user_reviews,
        'recommendations': recommendations,
        'chat_count': chat_count,
    })


# ─── Destinations ─────────────────────────────────────────────────────────────

def destination_list(request):
    qs = Destination.objects.filter(is_active=True)
    query = request.GET.get('q', '')
    category = request.GET.get('category', '')
    budget = request.GET.get('budget', '')
    sort = request.GET.get('sort', '-rating')

    if query:
        qs = qs.filter(Q(name__icontains=query) | Q(city__icontains=query) | Q(state__icontains=query))
        if request.user.is_authenticated:
            SearchLog.objects.create(user=request.user, keyword=query, results_count=qs.count())

    if category:
        qs = qs.filter(category__slug=category)
    if budget:
        qs = qs.filter(budget=budget)

    sort_options = {
        '-rating': '-rating',
        'rating': 'rating',
        '-visit_count': '-visit_count',
        'name': 'name',
    }
    qs = qs.order_by(sort_options.get(sort, '-rating'))

    categories = Category.objects.all()
    return render(request, 'core/destinations.html', {
        'destinations': qs,
        'categories': categories,
        'query': query,
        'selected_category': category,
        'selected_budget': budget,
        'selected_sort': sort,
        'total': qs.count(),
    })


def destination_detail(request, slug):
    destination = get_object_or_404(Destination, slug=slug, is_active=True)
    destination.visit_count += 1
    destination.save(update_fields=['visit_count'])

    reviews = destination.reviews.select_related('user').all()
    avg_rating = reviews.aggregate(avg=Avg('rating'))['avg'] or 0

    user_review = None
    review_form = None
    booking_form = BookingForm()

    if request.user.is_authenticated:
        user_review = reviews.filter(user=request.user).first()
        if not user_review:
            review_form = ReviewForm()

    similar = Destination.objects.filter(
        category=destination.category, is_active=True
    ).exclude(pk=destination.pk)[:4]

    return render(request, 'core/destination_detail.html', {
        'destination': destination,
        'reviews': reviews,
        'avg_rating': round(avg_rating, 1),
        'user_review': user_review,
        'review_form': review_form,
        'booking_form': booking_form,
        'similar': similar,
    })


# ─── Reviews ─────────────────────────────────────────────────────────────────

@login_required
def add_review(request, slug):
    destination = get_object_or_404(Destination, slug=slug)
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.destination = destination
            review.user = request.user
            review.save()
            # Update destination rating
            avg = destination.reviews.aggregate(avg=Avg('rating'))['avg'] or 0
            destination.rating = round(avg, 1)
            destination.review_count = destination.reviews.count()
            destination.save(update_fields=['rating', 'review_count'])
            messages.success(request, 'Review submitted successfully!')
    return redirect('core:destination_detail', slug=slug)


# ─── Bookings ────────────────────────────────────────────────────────────────

@login_required
def book_destination(request, slug):
    destination = get_object_or_404(Destination, slug=slug)
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.destination = destination
            booking.save()
            messages.success(request, f'Booking for {destination.name} submitted!')
            return redirect('core:my_bookings')
    return redirect('core:destination_detail', slug=slug)


@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user).select_related('destination')
    return render(request, 'core/my_bookings.html', {'bookings': bookings})


@login_required
def cancel_booking(request, pk):
    booking = get_object_or_404(Booking, pk=pk, user=request.user)
    booking.status = 'cancelled'
    booking.save()
    messages.info(request, 'Booking cancelled.')
    return redirect('core:my_bookings')


# ─── Recommendations ─────────────────────────────────────────────────────────

@login_required
def recommendations_view(request):
    recs = get_recommendations(request.user, limit=12)
    return render(request, 'core/recommendations.html', {'recommendations': recs})


# ─── Reports ─────────────────────────────────────────────────────────────────

@login_required
def reports_view(request):
    # User activity stats
    my_bookings_count = Booking.objects.filter(user=request.user).count()
    my_reviews_count = Review.objects.filter(user=request.user).count()
    chat_sessions = request.user.chat_sessions.count()

    # Top destinations
    top_destinations = Destination.objects.filter(is_active=True).order_by('-visit_count')[:10]

    # Popular categories
    cat_data = Category.objects.annotate(
        dest_count=Count('destinations')
    ).order_by('-dest_count')[:8]

    # Recent searches
    searches = SearchLog.objects.filter(user=request.user).order_by('-created_at')[:10]

    # Rating distribution across all reviews by this user
    user_ratings = Review.objects.filter(user=request.user).values('rating').annotate(count=Count('rating'))

    # Monthly booking trend (last 6 months)
    monthly_bookings = []
    for i in range(5, -1, -1):
        month_start = timezone.now().replace(day=1) - timedelta(days=30 * i)
        count = Booking.objects.filter(
            user=request.user,
            created_at__year=month_start.year,
            created_at__month=month_start.month
        ).count()
        monthly_bookings.append({
            'month': month_start.strftime('%b %Y'),
            'count': count
        })

    return render(request, 'core/reports.html', {
        'my_bookings_count': my_bookings_count,
        'my_reviews_count': my_reviews_count,
        'chat_sessions': chat_sessions,
        'top_destinations': top_destinations,
        'cat_data': cat_data,
        'searches': searches,
        'user_ratings': list(user_ratings),
        'monthly_bookings': monthly_bookings,
    })


# ─── Admin Reports ────────────────────────────────────────────────────────────

@login_required
def admin_reports(request):
    if not request.user.is_staff:
        messages.error(request, 'Access denied.')
        return redirect('core:home')

    from django.contrib.auth.models import User as AuthUser
    total_users = AuthUser.objects.count()
    total_destinations = Destination.objects.count()
    total_bookings = Booking.objects.count()
    total_reviews = Review.objects.count()

    # Top visited destinations
    top_visited = Destination.objects.order_by('-visit_count')[:10]

    # Popular categories
    cat_stats = Category.objects.annotate(
        dest_count=Count('destinations'),
        booking_count=Count('destinations__bookings')
    )

    # Recent activity
    recent_bookings = Booking.objects.select_related('user', 'destination').order_by('-created_at')[:10]
    recent_reviews = Review.objects.select_related('user', 'destination').order_by('-created_at')[:10]

    return render(request, 'core/admin_reports.html', {
        'total_users': total_users,
        'total_destinations': total_destinations,
        'total_bookings': total_bookings,
        'total_reviews': total_reviews,
        'top_visited': top_visited,
        'cat_stats': cat_stats,
        'recent_bookings': recent_bookings,
        'recent_reviews': recent_reviews,
    })
