"""
Simple AI Recommendation Engine.
Uses user preferences and history to suggest destinations.
"""
from django.db.models import Count
from .models import Destination, Recommendation, Review, Booking


def get_recommendations(user, limit=6):
    """
    Generate personalized destination recommendations for a user.
    Strategy:
    1. If user has profile preferences → filter by travel type & budget
    2. If user has reviews/bookings → find similar destinations
    3. Fallback → top rated destinations
    """
    profile = getattr(user, 'profile', None)
    already_visited = set(
        Booking.objects.filter(user=user).values_list('destination_id', flat=True)
    )
    reviewed = set(
        Review.objects.filter(user=user).values_list('destination_id', flat=True)
    )
    exclude_ids = already_visited | reviewed

    # Preference-based
    qs = Destination.objects.filter(is_active=True).exclude(id__in=exclude_ids)

    if profile and profile.travel_type:
        # Map travel type to categories
        type_to_cat = {
            'adventure': ['Adventure', 'Trekking'],
            'leisure': ['Leisure', 'Parks'],
            'heritage': ['Heritage', 'Culture', 'Historical'],
            'nature': ['Nature', 'Wildlife', 'Forest'],
            'beach': ['Beach', 'Coastal'],
            'mountain': ['Mountain', 'Hill Station'],
            'religious': ['Religious', 'Spiritual', 'Temple'],
        }
        cats = type_to_cat.get(profile.travel_type, [])
        if cats:
            qs = qs.filter(category__name__in=cats) or qs

    if profile and profile.budget_pref:
        budget_map = {'budget': ['free', 'budget'], 'mid': ['mid'], 'luxury': ['luxury', 'premium']}
        budgets = budget_map.get(profile.budget_pref, [])
        if budgets:
            qs = qs.filter(budget__in=budgets)

    results = list(qs.order_by('-rating', '-visit_count')[:limit])

    # If not enough results, fill with top rated
    if len(results) < limit:
        fallback = Destination.objects.filter(is_active=True).exclude(
            id__in=[d.id for d in results]
        ).order_by('-rating')[:limit - len(results)]
        results += list(fallback)

    # Save recommendations
    Recommendation.objects.filter(user=user).delete()
    for dest in results:
        Recommendation.objects.create(user=user, destination=dest, score=float(dest.rating))

    return results
