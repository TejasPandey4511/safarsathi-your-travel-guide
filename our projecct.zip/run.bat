@echo off
if exist "D:\webcoss\env\Scripts\python.exe" (
    set PYTHON=D:\webcoss\env\Scripts\python.exe
) else (
    set PYTHON=venv\Scripts\python.exe
)
echo Starting Travel Buddy...
echo Open: http://127.0.0.1:8000
%PYTHON% manage.py runserver
